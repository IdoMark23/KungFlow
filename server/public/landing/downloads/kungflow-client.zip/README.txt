KungFlow cloud client
=====================

1. Install the .NET 10 Desktop Runtime for Windows x64:
   https://dotnet.microsoft.com/download/dotnet/10.0
2. Open desktop/KungFlow.Desktop.UI.exe.

This build connects to: https://34-46-238-54.sslip.io
