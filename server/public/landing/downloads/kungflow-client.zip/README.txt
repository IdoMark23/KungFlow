KungFlow cloud client
=====================

Desktop application
-------------------
1. Install the .NET 10 Desktop Runtime for Windows x64:
   https://dotnet.microsoft.com/download/dotnet/10.0
2. Open desktop/KungFlow.Desktop.UI.exe.

The desktop app connects securely to the hosted KungFlow API.
