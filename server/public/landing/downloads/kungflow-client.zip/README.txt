KungFlow cloud client
=====================

Desktop application
-------------------
1. Install the .NET 10 Desktop Runtime for Windows x64:
   https://dotnet.microsoft.com/download/dotnet/10.0
2. Open desktop/KungFlow.Desktop.UI.exe.

Chrome extension
----------------
1. Open chrome://extensions in Chrome.
2. Enable Developer mode.
3. Choose Load unpacked.
4. Select the chrome-extension folder from this package.

Both clients connect securely to the hosted KungFlow API.
