const KUNGFLOW_API_BASE_URL = "https://34-46-238-54.sslip.io";

async function kungFlowApiRequest(path, options = {}) {
  const response = await fetch(`${KUNGFLOW_API_BASE_URL}${path}`, {
    ...options,
    headers: {
      "content-type": "application/json",
      ...(options.headers || {})
    }
  });
  const body = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(body.error || "KungFlow server request failed.");
  }

  return body;
}

async function kungFlowRegister({ email, username, password }) {
  return kungFlowApiRequest("/api/auth/register", {
    method: "POST",
    body: JSON.stringify({
      email,
      username,
      password
    })
  });
}

async function kungFlowLogin({ email, password, platform = "extension" }) {
  return kungFlowApiRequest("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({
      email,
      password,
      platform
    })
  });
}

async function kungFlowAuthorizedApiRequest(path, accessToken, options = {}) {
  return kungFlowApiRequest(path, {
    ...options,
    headers: {
      authorization: `Bearer ${accessToken}`,
      ...(options.headers || {})
    }
  });
}

async function kungFlowSendMetrics({
  accessToken,
  timestamp,
  platform = "extension",
  metrics
}) {
  return kungFlowAuthorizedApiRequest("/api/metrics", accessToken, {
    method: "POST",
    body: JSON.stringify({
      timestamp,
      platform,
      metrics
    })
  });
}

async function kungFlowGetCurrentStatus({ accessToken }) {
  return kungFlowAuthorizedApiRequest("/api/status/current", accessToken);
}

async function kungFlowLogout({ accessToken }) {
  return kungFlowAuthorizedApiRequest("/api/auth/logout", accessToken, {
    method: "POST"
  });
}

async function kungFlowChangePassword({
  accessToken,
  currentPassword,
  newPassword,
  confirmNewPassword
}) {
  return kungFlowAuthorizedApiRequest("/api/auth/change-password", accessToken, {
    method: "POST",
    body: JSON.stringify({
      currentPassword,
      newPassword,
      confirmNewPassword
    })
  });
}

async function kungFlowCreateDemoBaseline({ accessToken }) {
  return kungFlowAuthorizedApiRequest("/api/demo/baseline", accessToken, {
    method: "POST"
  });
}

async function kungFlowCreateDemoOverload({ accessToken }) {
  return kungFlowAuthorizedApiRequest("/api/demo/overload", accessToken, {
    method: "POST"
  });
}

async function kungFlowResetDemoMetrics({ accessToken }) {
  return kungFlowAuthorizedApiRequest("/api/demo/reset-metrics", accessToken, {
    method: "POST"
  });
}
